﻿namespace Project_Hlasny
{
    partial class MAPS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_LEVEL1 = new System.Windows.Forms.Button();
            this.button_LEVEL2 = new System.Windows.Forms.Button();
            this.button_LEVEL3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button_LEVEL1
            // 
            this.button_LEVEL1.Location = new System.Drawing.Point(96, 62);
            this.button_LEVEL1.Name = "button_LEVEL1";
            this.button_LEVEL1.Size = new System.Drawing.Size(75, 23);
            this.button_LEVEL1.TabIndex = 0;
            this.button_LEVEL1.Text = "Forest";
            this.button_LEVEL1.UseVisualStyleBackColor = true;
            this.button_LEVEL1.Click += new System.EventHandler(this.button_LEVEL1_Click);
            // 
            // button_LEVEL2
            // 
            this.button_LEVEL2.Location = new System.Drawing.Point(96, 91);
            this.button_LEVEL2.Name = "button_LEVEL2";
            this.button_LEVEL2.Size = new System.Drawing.Size(75, 23);
            this.button_LEVEL2.TabIndex = 1;
            this.button_LEVEL2.Text = "Cave";
            this.button_LEVEL2.UseVisualStyleBackColor = true;
            this.button_LEVEL2.Click += new System.EventHandler(this.button_LEVEL2_Click);
            // 
            // button_LEVEL3
            // 
            this.button_LEVEL3.Location = new System.Drawing.Point(96, 120);
            this.button_LEVEL3.Name = "button_LEVEL3";
            this.button_LEVEL3.Size = new System.Drawing.Size(75, 23);
            this.button_LEVEL3.TabIndex = 2;
            this.button_LEVEL3.Text = "Space";
            this.button_LEVEL3.UseVisualStyleBackColor = true;
            this.button_LEVEL3.Click += new System.EventHandler(this.button_LEVEL3_Click);
            // 
            // MAPS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.button_LEVEL3);
            this.Controls.Add(this.button_LEVEL2);
            this.Controls.Add(this.button_LEVEL1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "MAPS";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MAPS";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_LEVEL1;
        private System.Windows.Forms.Button button_LEVEL2;
        private System.Windows.Forms.Button button_LEVEL3;
    }
}