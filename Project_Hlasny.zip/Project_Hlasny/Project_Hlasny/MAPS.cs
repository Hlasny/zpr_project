﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Hlasny
{
    public partial class MAPS : Form
    {
        public MAPS()
        {
            InitializeComponent();
        }

        private void button_LEVEL1_Click(object sender, EventArgs e)
        {
            this.Hide();

            LEVEL1 lvl1 = new LEVEL1();
            lvl1.ShowDialog();

            this.Close();
        }

        private void button_LEVEL2_Click(object sender, EventArgs e)
        {
            this.Hide();

            LEVEL2 lvl2 = new LEVEL2();
            lvl2.ShowDialog();

            this.Close();
        }

        private void button_LEVEL3_Click(object sender, EventArgs e)
        {
            this.Hide();

            LEVEL3 lvl3 = new LEVEL3();
            lvl3.ShowDialog();

            this.Close();
        }
    }
}
