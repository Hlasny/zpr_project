﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Hlasny
{
    public partial class LEVEL1 : Form
    {

        System.Media.SoundPlayer player = new System.Media.SoundPlayer();

        private World _world;

        public LEVEL1()
        {
            InitializeComponent();

            this._world = new World(this.pictureBox1.Width, this.pictureBox1.Height);
            player.SoundLocation = "Silence.wav";
            player.Play();

            timer2.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this._world.Next();
            this.pictureBox1.Refresh();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            this.Opacity += .004;
            if (this.Opacity == 1)
            {
                timer2.Stop();
            }
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            this._world.Render(e.Graphics);
        }
    }
}
