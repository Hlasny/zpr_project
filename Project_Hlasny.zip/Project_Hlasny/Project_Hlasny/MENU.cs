﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Hlasny
{
    public partial class MENU : Form
    {
        public MENU()
        {
            InitializeComponent();
        }

        private void button_Start_Click(object sender, EventArgs e)
        {
            this.Hide();

            LEVEL1 lvl1 = new LEVEL1();
            lvl1.ShowDialog();

            this.Close();
        }

        private void button_Maps_Click(object sender, EventArgs e)
        {
            MAPS m = new MAPS();
            m.ShowDialog();
        }

        private void button_Settings_Click(object sender, EventArgs e)
        {
            SETTINGS s = new SETTINGS();
            s.ShowDialog();
        }

        private void button_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
