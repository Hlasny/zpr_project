﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Hlasny
{
    public class Player
    {
        public int RadiusP { get; set; } = 10;

        public double X { get; set; }

        public double Y { get; set; }

        public double Vx { get; set; }

        public double Vy { get; set; }

        public void RenderP(Graphics g)
        {
            g.FillEllipse(Brushes.Blue, Convert.ToInt32(this.X - RadiusP), Convert.ToInt32(this.Y - RadiusP), 2 * RadiusP, 2 * RadiusP);
        }

        public void MoveP()
        {
            this.X += this.Vx;
            this.Y += this.Vy;

            this.Vx *= 0.99;
            this.Vy *= 0.99;
        }

        public void Collide(int width, int height)
        {
            if (this.X - this.RadiusP <= 0 || this.X + this.RadiusP >= width)
                this.Vx *= -1;

            if (this.Y - this.RadiusP <= 0 || this.Y + this.RadiusP >= height)
                this.Vy *= -1;
        }

        public bool CollideWithEnemy(Player p)
        {
            double dist = Math.Sqrt(Math.Pow(this.X - p.X, 2) + Math.Pow(this.Y - p.Y, 2));

            return (dist <= this.RadiusP + p.RadiusP);
        }
    }
}
