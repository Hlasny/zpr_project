﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Hlasny
{
    public class Enemy
    {
        public int RadiusE { get; set; } = 5;

        public double X { get; set; }

        public double Y { get; set; }

        public double Vx { get; set; }

        public double Vy { get; set; }

        public void RenderE(Graphics g)
        {
            g.FillEllipse(Brushes.Red, Convert.ToInt32(this.X - RadiusE), Convert.ToInt32(this.Y - RadiusE), 2 * RadiusE, 2 * RadiusE);
        }

        public void MoveE()
        {
            this.X += this.Vx;
            this.Y += this.Vy;

            this.Vx *= 0.99;
            this.Vy *= 0.99;
        }
    }
}
