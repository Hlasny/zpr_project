﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Hlasny
{
    public class World
    {
        private int _width;
        private int _height;
   
        //private List<Enemy> _enemies = new List<Enemy>();
        private Enemy _enemy = new Enemy();
        private Player _player = new Player();

        public World(int width, int height)
        {
            this._width = width;
            this._height = height;

            this._player.X = 200;
            this._player.Y = 200;

            this._enemy.X = 250;
            this._enemy.Y = 250;

            this._enemy.Vy = -1;

            this._player.Vx = 2;


        }

        public void Next()
        {
            //foreach (Enemy item in this._enemies)
            //{
            //    item.MoveE();
            //}

            this._enemy.MoveE();
            this._player.MoveP();
            this._player.Collide(this._width, this._height);
        }

        internal void Render(object graphics)
        {
            throw new NotImplementedException();
        }

        public void Render(Graphics g)
        {
            //foreach (Enemy item in this._enemies)
            //{
            //    item.RenderE(g);
            //}

            this._player.RenderP(g);
            this._enemy.RenderE(g);
        }

        public void AddEnemy(Enemy e)
        {
            this._enemy = e;
        }

        public void AddPlayer(Player p)
        {
            this._player = p;
        }

        //public void GenerateEnemies(double x, double y)
        //{
        //    int velocity = 10;
        //    for (int i = 0; i < 8; i++)
        //    {
        //        double vx = velocity;
        //        double vy = velocity;

        //        Enemy e = new Enemy();
        //        e.X = x;
        //        e.Y = y;
        //        e.Vx = vx;
        //        e.Vy = vy;

        //        this._enemies.Add(e);
        //    }
        //}
    }
}
